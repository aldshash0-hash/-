const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret, defineString } = require("firebase-functions/params");
const admin = require("firebase-admin");
const crypto = require("crypto");
admin.initializeApp();
const db = admin.firestore();
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");

// 3) دخول المدير بثلاث خطوات: حساب مسموح + الرمز السري + رمز من 6 أرقام يصل إلى بريدك
// ANY_ACCOUNT=true: يُسمح لأي حساب بطلب الدخول | false: فقط الإيميلات في ADMIN_EMAILS (مفصولة بفاصلة)
const ADMIN_EMAILS = defineString("ADMIN_EMAILS", { default: "" });
const ANY_ACCOUNT = defineString("ANY_ACCOUNT", { default: "false" });
const OTP_EMAIL = defineString("OTP_EMAIL", { default: "" }); // الجيميل الذي يُرسل منه الرمز ويستلمه
const ADMIN_CODE = defineSecret("ADMIN_CODE");
const GMAIL_PASS = defineSecret("GMAIL_APP_PASSWORD");
const same = (x, y) => crypto.timingSafeEqual(Buffer.from(sha(x)), Buffer.from(sha(y)));
function needAdminAccount(req) {
  if (!req.auth || !req.auth.token.email_verified) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const admins = ADMIN_EMAILS.value().split(",").map((x) => x.trim().toLowerCase()).filter(Boolean);
  if (ANY_ACCOUNT.value() !== "true" && !admins.includes(String(req.auth.token.email).toLowerCase()))
    throw new HttpsError("permission-denied", "هذا الحساب غير مصرّح له بدخول وضع المدير");
}

exports.requestAdminOtp = onCall({ secrets: [ADMIN_CODE, GMAIL_PASS] }, async (req) => {
  needAdminAccount(req);
  const uid = req.auth.uid;
  const ref = db.doc(`adminAttempts/${uid}`);
  const st = (await ref.get()).data() || { n: 0, until: 0 };
  if (st.until > Date.now()) throw new HttpsError("resource-exhausted", "محاولات كثيرة، حاول بعد 15 دقيقة");
  if (!same(String(req.data.code || ""), ADMIN_CODE.value())) {
    const n = st.n + 1;
    await ref.set({ n: n >= 5 ? 0 : n, until: n >= 5 ? Date.now() + 15 * 60000 : 0 });
    throw new HttpsError("permission-denied", "الرمز السري غير صحيح");
  }
  await ref.set({ n: 0, until: 0 });
  const to = OTP_EMAIL.value();
  if (!to) throw new HttpsError("failed-precondition", "لم يُضبط بريد استلام الرمز (OTP_EMAIL)");
  const o = db.doc(`adminOtp/${uid}`);
  const prev = (await o.get()).data();
  if (prev && Date.now() - prev.sent < 60000) throw new HttpsError("resource-exhausted", "انتظر دقيقة قبل طلب رمز جديد");
  const otp = String(crypto.randomInt(100000, 1000000));
  try {
    const tr = require("nodemailer").createTransport({ service: "gmail", auth: { user: to, pass: GMAIL_PASS.value() } });
    await tr.sendMail({
      from: `العكريشي <${to}>`, to, subject: "رمز تأكيد دخول المدير",
      text: `رمز التأكيد: ${otp}\nصالح لمدة 10 دقائق. لا تشاركه مع أحد.\nإن لم تطلبه أنت فتجاهل الرسالة وغيّر الرمز السري فورًا.`,
    });
  } catch (e) { console.error(e); throw new HttpsError("internal", "تعذّر إرسال الرسالة، راجع إعدادات البريد"); }
  await o.set({ h: sha(otp + uid), exp: Date.now() + 10 * 60000, n: 0, sent: Date.now() });
  return { masked: to.replace(/^(.).*(.@)/, "$1***$2") };
});

exports.verifyAdminOtp = onCall(async (req) => {
  needAdminAccount(req);
  const uid = req.auth.uid, ref = db.doc(`adminOtp/${uid}`), d = (await ref.get()).data();
  if (!d || d.exp < Date.now()) throw new HttpsError("failed-precondition", "انتهت صلاحية الرمز، اطلب رمزًا جديدًا");
  if (d.n >= 5) { await ref.delete(); throw new HttpsError("resource-exhausted", "محاولات كثيرة، اطلب رمزًا جديدًا"); }
  const given = sha(String(req.data.otp || "") + uid);
  if (!crypto.timingSafeEqual(Buffer.from(given), Buffer.from(String(d.h)))) {
    await ref.update({ n: d.n + 1 });
    throw new HttpsError("permission-denied", "الرمز غير صحيح");
  }
  await ref.delete();
  await admin.auth().setCustomUserClaims(uid, { admin: true, until: Date.now() + 8 * 3600 * 1000 });
  return { ok: true };
});

// 4) تصحيح الاختبار على الخادم (الإجابات الصحيحة لا تصل لمتصفح الطالب أبدًا)
exports.submitQuiz = onCall(async (req) => {
  if (!req.auth || !req.auth.token.email_verified) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const uid = req.auth.uid, { courseId, lessonId } = req.data || {};
  const answers = Array.isArray(req.data.answers) ? req.data.answers : [];
  const l = (await db.doc(`courses/${courseId}/lessons/${lessonId}`).get()).data();
  if (!l) throw new HttpsError("not-found", "الدرس غير موجود");
  const ok = l.free || (await db.doc(`enrollments/${uid}_${courseId}`).get()).exists;
  if (!ok) throw new HttpsError("permission-denied", "اشترك في الكورس أولًا");
  const key = (await db.doc(`courses/${courseId}/answers/${lessonId}`).get()).data();
  if (!key) throw new HttpsError("failed-precondition", "لا يوجد اختبار لهذا الدرس");
  const wrong = key.a.map((x, i) => (x === answers[i] ? -1 : i)).filter((i) => i >= 0);
  const score = key.a.length - wrong.length;
  await db.doc(`scores/${uid}_${lessonId}`).set({ uid, courseId, lessonId, title: l.title, score, total: key.a.length, at: Date.now() });
  return { score, total: key.a.length, wrong };
});
