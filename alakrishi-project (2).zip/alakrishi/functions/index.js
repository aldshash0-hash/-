const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret, defineString } = require("firebase-functions/params");
const admin = require("firebase-admin");
const crypto = require("crypto");
admin.initializeApp();
const db = admin.firestore();
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");

// 3) دخول المدير: الإيميل المحدد + الرمز السري، فيحصل على تصريح مؤقت 8 ساعات
const ADMIN_EMAIL = defineString("ADMIN_EMAIL");
const ADMIN_CODE = defineSecret("ADMIN_CODE");
exports.verifyAdminCode = onCall({ secrets: [ADMIN_CODE] }, async (req) => {
  if (!req.auth || !req.auth.token.email_verified) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  if (req.auth.token.email !== ADMIN_EMAIL.value()) throw new HttpsError("permission-denied", "غير مصرّح");
  const ref = db.doc(`adminAttempts/${req.auth.uid}`);
  const st = (await ref.get()).data() || { n: 0, until: 0 };
  if (st.until > Date.now()) throw new HttpsError("resource-exhausted", "محاولات كثيرة، حاول بعد 15 دقيقة");
  const good = crypto.timingSafeEqual(Buffer.from(sha(String(req.data.code || ""))), Buffer.from(sha(ADMIN_CODE.value())));
  if (!good) {
    const n = st.n + 1;
    await ref.set({ n: n >= 5 ? 0 : n, until: n >= 5 ? Date.now() + 15 * 60000 : 0 });
    throw new HttpsError("permission-denied", "الرمز غير صحيح");
  }
  await ref.set({ n: 0, until: 0 });
  await admin.auth().setCustomUserClaims(req.auth.uid, { admin: true, until: Date.now() + 8 * 3600 * 1000 });
  return { ok: true };
});

// 4) تصحيح الاختبار على الخادم (الإجابات الصحيحة لا تصل لمتصفح الطالب أبدًا)
exports.submitQuiz = onCall(async (req) => {
  if (!req.auth || !req.auth.token.email_verified) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  const uid = req.auth.uid, { courseId, lessonId } = req.data || {};
  const answers = Array.isArray(req.data.answers) ? req.data.answers : [];
  const l = (await db.doc(`courses/${courseId}/lessons/${lessonId}`).get()).data();
  if (!l) throw new HttpsError("not-found", "الدرس غير موجود");
  const ok = l.free || (await db.doc(`enrollments/${uid}_${courseId}`).get()).exists;
  if (!ok) throw new HttpsError("permission-denied", "اشترك في الكورس أولًا");
  const key = (await db.doc(`courses/${courseId}/answers/${lessonId}`).get()).data();
  if (!key) throw new HttpsError("failed-precondition", "لا يوجد اختبار لهذا الدرس");
  const wrong = key.a.map((x, i) => (x === answers[i] ? -1 : i)).filter((i) => i >= 0);
  const score = key.a.length - wrong.length;
  await db.doc(`scores/${uid}_${lessonId}`).set({ uid, courseId, lessonId, title: l.title, score, total: key.a.length, at: Date.now() });
  return { score, total: key.a.length, wrong };
});
